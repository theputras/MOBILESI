<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Api\apiprodukscontroller;

// // Route::get("/test", [ApiProdukController::class, "test"]);
// // Route test sederhana
// Route::get('/test', function () {
//     return response()->json([
//         'success' => true,
//         'message' => 'Hello World! API is working perfectly!',
//         'data' => [
//             'timestamp' => now(),
//             'version' => '1.0.0',
//             'status' => 'active'
//         ]
//     ]);
// });

// // Route untuk testing dengan parameter
// Route::get('/test/{name}', function ($name) {
//     return response()->json([
//         'success' => true,
//         'message' => "Hello {$name}! Welcome to our API!",
//         'data' => [
//             'user' => $name,
//             'timestamp' => now()
//         ]
//     ]);
// });


// Route untuk Query Builder
Route::get('produk/qb', [apiprodukscontroller::class, 'index_qb']);
Route::post('produk/qb', [apiprodukscontroller::class, 'store_qb']);
Route::get('produk/qb/{id}', [apiprodukscontroller::class, 'show_qb']);
Route::put('produk/qb/{id}', [apiprodukscontroller::class, 'update_qb']);
Route::delete('produk/qb/{id}', [apiprodukscontroller::class, 'destroy_qb']);

// Route untuk ORM 
Route::get('produk/orm', [apiprodukscontroller::class, 'index_orm']);
Route::post('produk/orm', [apiprodukscontroller::class, 'store_orm']);
Route::get('produk/orm/{id}', [apiprodukscontroller::class, 'show_orm']);
Route::put('produk/orm/{id}', [apiprodukscontroller::class, 'update_orm']);
Route::delete('produk/orm/{id}', [apiprodukscontroller::class, 'destroy_orm']);

Route::get('tes', [apiprodukscontroller::class, 'test']);
// bacaqb and bacaorm kept for legacy check, mapping to new methods
Route::get('bacaqb', [apiprodukscontroller::class, 'index_qb']);
Route::get('bacaorm', [apiprodukscontroller::class, 'index_orm']);

