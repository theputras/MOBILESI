<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>CRUD </title>
    <style>
        body {
            font-family: sans-serif;
            padding: 20px;
        }

        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        .form-group {
            margin-bottom: 10px;
        }

        label {
            display: inline-block;
            width: 100px;
        }

        input {
            padding: 5px;
        }

        button {
            padding: 5px 10px;
            cursor: pointer;
        }

        .btn-danger {
            background-color: #ff4d4d;
            color: white;
            border: none;
        }

        .btn-primary {
            background-color: #4d94ff;
            color: white;
            border: none;
        }

        .btn-warning {
            background-color: #ffc107;
            border: none;
        }
    </style>
</head>

<body>

    <h2>CRUD Produk</h2>

    <!-- Form for Add/Edit -->
    <div style="border: 1px solid #ccc; padding: 15px; background: #fafafa;">
        <h3 id="formDistitle">Tambah Produk</h3>
        <form id="productForm">
            <input type="hidden" id="productId">
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="satuan">Satuan:</label>
                <input type="text" id="satuan" name="satuan">
            </div>
            <div class="form-group">
                <label for="harga">Harga:</label>
                <input type="number" id="harga" name="harga" required>
            </div>
            <button type="submit" class="btn-primary" id="submitBtn">Simpan</button>
            <button type="button" onclick="resetForm()" style="display:none;" id="cancelBtn">Batal</button>
        </form>
    </div>

    <!-- Table List -->
    <h3>Daftar Produk</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Satuan</th>
                <th>Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            @if(isset($data['data']))
                @foreach ($data['data'] as $x)
                    <tr>
                        <td>{{ $x['id'] }}</td>
                        <td>{{ $x['nama'] }}</td>
                        <td>{{ $x['satuan'] }}</td>
                        <td>{{ $x['harga'] }}</td>
                        <td>
                            <button class="btn-warning" onclick='editProduct(@json($x))'>Edit</button>
                            <button class="btn-danger" onclick="deleteProduct({{ $x['id'] }})">Hapus</button>
                        </td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="5">Tidak ada data ({{ $data['message'] ?? 'Error' }})</td>
                </tr>
            @endif
        </tbody>
    </table>

    <script>
        const form = document.getElementById('productForm');
        const submitBtn = document.getElementById('submitBtn');
        const cancelBtn = document.getElementById('cancelBtn');
        const formTitle = document.getElementById('formTitle');
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

        form.addEventListener('submit', function (e) {
            e.preventDefault();

            const id = document.getElementById('productId').value;
            const nama = document.getElementById('nama').value;
            const satuan = document.getElementById('satuan').value;
            const harga = document.getElementById('harga').value;

            const url = id ? `/produk/qb/${id}` : '/produk/qb';
            const method = id ? 'PUT' : 'POST';

            fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': csrfToken
                },
                body: JSON.stringify({ nama, satuan, harga })
            })
                .then(response => response.json())
                .then(data => {
                    alert(data.message);
                    if (data.style === 'Query Builder') {
                        window.location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('Terjadi kesalahan');
                });
        });

        function deleteProduct(id) {
            if (confirm('Yakin ingin menghapus produk ini?')) {
                fetch(`/produk/qb/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-CSRF-TOKEN': csrfToken
                    }
                })
                    .then(response => response.json())
                    .then(data => {
                        alert(data.message);
                        window.location.reload();
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        alert('Gagal menghapus');
                    });
            }
        }

        function editProduct(product) {
            document.getElementById('formDistitle').innerText = 'Edit Produk #' + product.id;
            document.getElementById('productId').value = product.id;
            document.getElementById('nama').value = product.nama;
            document.getElementById('satuan').value = product.satuan;
            document.getElementById('harga').value = product.harga;

            submitBtn.innerText = 'Update';
            cancelBtn.style.display = 'inline-block';
        }

        function resetForm() {
            document.getElementById('formDistitle').innerText = 'Tambah Produk';
            document.getElementById('productId').value = '';
            form.reset();
            submitBtn.innerText = 'Simpan';
            cancelBtn.style.display = 'none';
        }
    </script>
</body>

</html>