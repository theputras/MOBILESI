<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Http;

use GuzzleHttp\Promise\PromiseInterface;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class Controller
{
    public function tes()
    {
        $response = Http::get('http://127.0.0.1/W12/api/produk/qb');
        $json = $response->json();

        $products = $json['data'] ?? [];

        // Sort by ID descending so the newest appear first
        $products = collect($products)->sortByDesc('id')->values()->all();

        $viewData = [
            'data' => $products,
            'message' => $json['message'] ?? 'Data loaded'
        ];

        return view('tampil', ['data' => $viewData]);
    }

    public function index_qb()
    {
        $response = Http::get('http://127.0.0.1/W12/api/produk/qb');
        $data = $response->json();
        return response()->json(['style' => 'Query Builder', 'message' => 'Data Produk', 'data' => $data], 200);
    }

    public function store_qb(Request $request)
    {
        $validasi = Validator::make($request->all(), [
            'nama' => 'required',
            'satuan' => 'nullable',
            'harga' => 'required|numeric'
        ]);

        if ($validasi->fails()) {
            return response()->json(['style' => 'Query Builder', 'message' => 'Gagal validasi', 'errors' => $validasi->errors()], 400);
        }

        $response = Http::post('http://127.0.0.1/W12/api/produk/qb', [
            'nama' => $request->nama,
            'satuan' => $request->satuan,
            'harga' => $request->harga,
        ]);

        // Assuming the remote API returns the created object or we just return the input + ID from remote
        $savedData = $response->json();

        return response()->json(['style' => 'Query Builder', 'message' => 'Berhasil input data', 'data' => $savedData], 201);
    }

    public function show_qb(string $id)
    {
        $response = Http::get('http://127.0.0.1/W12/api/produk/qb/' . $id);
        $data = $response->json();

        if ($response->successful() && $data) {
            return response()->json(['style' => 'Query Builder', 'message' => 'Data ditemukan', 'data' => $data], 200);
        }
        return response()->json(['style' => 'Query Builder', 'message' => 'Data tidak ditemukan'], 404);
    }

    public function update_qb(Request $request, string $id)
    {
        $validasi = Validator::make($request->all(), [
            'nama' => 'required',
            'satuan' => 'nullable',
            'harga' => 'required|numeric'
        ]);

        if ($validasi->fails()) {
            return response()->json(['style' => 'Query Builder', 'message' => 'Gagal validasi', 'errors' => $validasi->errors()], 400);
        }

        $response = Http::put('http://127.0.0.1/W12/api/produk/qb/' . $id, [
            'nama' => $request->nama,
            'satuan' => $request->satuan,
            'harga' => $request->harga,
        ]);

        if ($response->successful()) {
            $data = $response->json();
            return response()->json(['style' => 'Query Builder', 'message' => 'Data berhasil diupdate', 'data' => $data], 200);
        }
        return response()->json(['style' => 'Query Builder', 'message' => 'Data tidak ditemukan'], 404);
    }

    public function destroy_qb(string $id)
    {
        $response = Http::delete('http://127.0.0.1/W12/api/produk/qb/' . $id);

        if ($response->successful()) {
            return response()->json(['style' => 'Query Builder', 'message' => 'Data berhasil dihapus'], 200);
        }
        return response()->json(['style' => 'Query Builder', 'message' => 'Data tidak ditemukan'], 404);
    }
}