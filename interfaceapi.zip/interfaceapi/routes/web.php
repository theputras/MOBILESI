<?php

use App\Http\Controllers\ProductController;
use App\Http\Controllers\Controller;

Route::get('/', [Controller::class, 'tes']);

Route::get('tampil', [ProductController::class, 'tampil']);
Route::get('tes', [Controller::class, 'tes']);

// Route untuk Query Builder
Route::get('produk/qb', [Controller::class, 'index_qb']);
Route::post('produk/qb', [Controller::class, 'store_qb']);
Route::get('produk/qb/{id}', [Controller::class, 'show_qb']);
Route::put('produk/qb/{id}', [Controller::class, 'update_qb']);
Route::delete('produk/qb/{id}', [Controller::class, 'destroy_qb']);