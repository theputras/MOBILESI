package com.theputras.posrentalps.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.theputras.posrentalps.R;
import com.theputras.posrentalps.model.Tv;
import java.util.List;

public class TvGridAdapter extends RecyclerView.Adapter<TvGridAdapter.ViewHolder> {

    private Context context;
    private List<Tv> tvList;
    private OnItemClickListener listener;

    public interface OnItemClickListener {
        void onItemClick(Tv tv);
    }

    public TvGridAdapter(Context context, List<Tv> tvList, OnItemClickListener listener) {
        this.context = context;
        this.tvList = tvList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Pastikan layout item_grid_tv.xml sudah ada
        View view = LayoutInflater.from(context).inflate(R.layout.item_grid_tv, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Tv tv = tvList.get(position);
        holder.tvNomor.setText(tv.getNomorTv()); // Misal: "TV 01"

        if (tv.getJenisConsole() != null) {
            holder.tvConsole.setText(tv.getJenisConsole().getNamaConsole());
        } else {
            holder.tvConsole.setText("-");
        }

        holder.tvStatus.setText(tv.getStatus());

        holder.itemView.setOnClickListener(v -> listener.onItemClick(tv));
    }

    @Override
    public int getItemCount() {
        return tvList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNomor, tvConsole, tvStatus;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNomor = itemView.findViewById(R.id.tvNomor);
            tvConsole = itemView.findViewById(R.id.tvConsoleType);
            tvStatus = itemView.findViewById(R.id.tvStatus);
        }
    }
}