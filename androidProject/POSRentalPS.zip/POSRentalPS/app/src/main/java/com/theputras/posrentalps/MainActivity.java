package com.theputras.posrentalps;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.theputras.posrentalps.adapter.PaketAdapter;
import com.theputras.posrentalps.adapter.TvGridAdapter;
import com.theputras.posrentalps.api.ApiClient;
import com.theputras.posrentalps.api.ApiService;
import com.theputras.posrentalps.model.PaketSewa;
import com.theputras.posrentalps.model.TransactionRequest;
import com.theputras.posrentalps.model.Tv;
import com.theputras.posrentalps.model.TvResponse;
import com.theputras.posrentalps.utils.CartManager;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import android.app.AlertDialog;
import android.text.InputType;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerTv;
    private TvGridAdapter adapter;
    private List<PaketSewa> allPakets = new ArrayList<>();
    private ExtendedFloatingActionButton fabCart; // Pake Extended biar mirip tombol checkout di gambar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerTv = findViewById(R.id.recyclerTvGrid);
        fabCart = findViewById(R.id.fabCart);

        // Grid 2 Kolom
        recyclerTv.setLayoutManager(new GridLayoutManager(this, 2));

        // Load Data
        fetchMasterData();

        // Tombol Cart di bawah (Floating)
        fabCart.setOnClickListener(v -> {
            if (!CartManager.getInstance().getDisplayList().isEmpty()) {
                startActivity(new Intent(this, PaymentActivity.class));
            } else {
                Toast.makeText(this, "Keranjang Kosong", Toast.LENGTH_SHORT).show();
            }
        });

        updateCartUI();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateCartUI();
        fetchTvs(); // Refresh status TV saat kembali ke menu utama
    }

    private void updateCartUI() {
        int count = CartManager.getInstance().getDisplayList().size();
        int total = CartManager.getInstance().getTotalPrice();

        // Ambil referensi badge merah juga
        TextView badge = findViewById(R.id.tvCartCount);

        if (count > 0) {
            // 1. Tampilkan Tombol Bayar (Extended FAB)
            if (fabCart.getVisibility() != View.VISIBLE) {
                fabCart.setVisibility(View.VISIBLE); // Paksa Visible dulu
                fabCart.show(); // Baru animasi muncul
            }
            fabCart.setText("Bayar (" + count + ") - Rp " + total);

            // 2. Tampilkan Badge Merah (Lingkaran kecil)
            badge.setVisibility(View.VISIBLE);
            badge.setText(String.valueOf(count));
        } else {
            // Sembunyikan jika kosong
            fabCart.hide();
            fabCart.setVisibility(View.GONE);
            badge.setVisibility(View.GONE);
        }
    }

    private void fetchMasterData() {
        // Ambil Paket dulu untuk cache local
        ApiClient.getClient().create(ApiService.class).getPakets().enqueue(new Callback<List<PaketSewa>>() {
            @Override
            public void onResponse(Call<List<PaketSewa>> call, Response<List<PaketSewa>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    allPakets = response.body();
                    fetchTvs(); // Setelah paket siap, ambil TV
                }
            }
            @Override public void onFailure(Call<List<PaketSewa>> c, Throwable t) {}
        });
    }

    private void fetchTvs() {
        ApiClient.getClient().create(ApiService.class).getAvailableTvs().enqueue(new Callback<TvResponse>() {
            @Override
            public void onResponse(Call<TvResponse> call, Response<TvResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    adapter = new TvGridAdapter(MainActivity.this, response.body().getData(), tv -> {
                        if (tv.getStatus().equalsIgnoreCase("available")) {
                            showPaketDialog(tv);
                        } else {
                            Toast.makeText(MainActivity.this, "TV sedang dipakai", Toast.LENGTH_SHORT).show();
                        }
                    });
                    recyclerTv.setAdapter(adapter);
                }
            }
            @Override public void onFailure(Call<TvResponse> c, Throwable t) {}
        });
    }

    // --- Bottom Sheet (Mirip Gambar 2 - Menu Item) ---
    private void showPaketDialog(Tv tv) {
        BottomSheetDialog dialog = new BottomSheetDialog(this, R.style.BottomSheetDialogTheme);
        View view = getLayoutInflater().inflate(R.layout.layout_pilih_paket, null);

        TextView title = view.findViewById(R.id.tvTitleSheet);
        RecyclerView recyclerPaket = view.findViewById(R.id.recyclerPaket);

        title.setText("Pilih Paket - " + tv.getNomorTv());

        // Filter paket berdasarkan Console TV (PS4/PS5)
        List<PaketSewa> filtered = new ArrayList<>();
        String consoleTv = (tv.getJenisConsole() != null) ? tv.getJenisConsole().getNamaConsole() : "";

        for (PaketSewa p : allPakets) {
            // Asumsi backend kirim nama_console di paket, atau kita filter manual by ID logic
            // Sederhananya: Tampilkan semua paket jika nama console cocok
            if (p.namaConsole != null && p.namaConsole.equalsIgnoreCase(consoleTv)) {
                filtered.add(p);
            }
        }

        recyclerPaket.setLayoutManager(new GridLayoutManager(this, 1));
        PaketAdapter paketAdapter = new PaketAdapter(filtered, selectedPaket -> {

            // 1. Buat Popup Input Jumlah
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Masukkan Jumlah (Pcs)");
            builder.setMessage("Berapa kali paket ini dipesan?");

            final EditText input = new EditText(this);
            input.setInputType(InputType.TYPE_CLASS_NUMBER);
            input.setText("1"); // Default 1
            builder.setView(input);

            // 2. Aksi saat tombol OK ditekan
            builder.setPositiveButton("Tambah", (dialogInterface, which) -> {
                String qtyStr = input.getText().toString();
                int qty = qtyStr.isEmpty() ? 1 : Integer.parseInt(qtyStr);

                if (qty < 1) {
                    Toast.makeText(this, "Jumlah minimal 1", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Validasi: Cek apa TV ini sudah ada di keranjang
                boolean isExist = false;
                for (CartManager.CartDisplay item : CartManager.getInstance().getDisplayList()) {
                    if (item.request.tvId == tv.getId()) {
                        isExist = true; break;
                    }
                }
                if (isExist) {
                    Toast.makeText(this, "TV ini sudah ada di keranjang!", Toast.LENGTH_LONG).show();
                    return;
                }

                // 3. Masukkan ke CartManager dengan Qty
                TransactionRequest req = new TransactionRequest(
                        "Guest",
                        tv.getId(),
                        selectedPaket.idPaket,
                        selectedPaket.harga // Harga satuan, nanti dikali qty di payment
                );

                // Panggil addItem yang baru (ada parameter qty)
                CartManager.getInstance().addItem(
                        req,
                        "TV " + tv.getNomorTv() + " - " + selectedPaket.namaPaket,
                        selectedPaket.harga,
                        qty
                );

                updateCartUI();
                dialog.dismiss(); // Tutup BottomSheet
                Toast.makeText(this, "Berhasil masuk keranjang", Toast.LENGTH_SHORT).show();
            });

            builder.setNegativeButton("Batal", (d, w) -> d.cancel());
            builder.show();
        });
    }
}