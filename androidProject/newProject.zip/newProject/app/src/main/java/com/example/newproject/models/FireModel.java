package com.example.newproject.models;

public class FireModel {
    String name, desc;

    public FireModel() {} // wajib
    public FireModel(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
}


