package com.example.newproject;

// RegisterResponse.java
public class RegisterResponse {
    private String message;
    private String token;

    public String getToken() {
        return token;
    }
}