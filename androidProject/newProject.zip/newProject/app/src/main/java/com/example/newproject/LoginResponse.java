package com.example.newproject;

// LoginResponse.java
public class LoginResponse {
    private String message;
    private String access_token;
    private String token_type;

    public String getAccessToken() {
        return access_token;
    }
}
