package com.example.newproject;

// LogoutResponse.java
public class LogoutResponse {
    private String message;
}