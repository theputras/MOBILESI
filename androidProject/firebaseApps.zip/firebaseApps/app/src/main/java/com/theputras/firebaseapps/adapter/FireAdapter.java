package com.theputras.firebaseapps.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.theputras.firebaseapps.R;
import com.theputras.firebaseapps.models.FireModel;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FireAdapter extends RecyclerView.Adapter<FireAdapter.ViewHolder> {

    private List<FireModel> data;
    private OnItemClickListener listener; // Listener buat klik

    // Interface biar Fragment bisa handle kliknya
    public interface OnItemClickListener {
        void onItemClick(FireModel model);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public FireAdapter(List<FireModel> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        FireModel model = data.get(position);
        holder.textViewNama.setText(model.getName());

        // Pasang aksi klik
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(model);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewNama;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewNama = itemView.findViewById(R.id.textViewNama);
        }
    }
}